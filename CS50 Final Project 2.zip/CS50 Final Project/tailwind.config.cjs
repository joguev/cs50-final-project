module.exports = {
  content: ["./app/static/js/**/*.{js,jsx}", "./app/templates/**/*.html"],
  theme: {
    extend: {},
  },
  plugins: [],
};
